# Architecture and roadmap

## Current starter
- UI: Jetpack Compose, dark dashboard, league chips, match cards.
- Domain: `FootballMatch`, `MatchPrediction`, baseline `PredictionEngine`.
- Data: `FootballDataSource` contract and clearly labelled demo fixtures.

## Production architecture
1. Android client (Compose + MVVM).
2. Backend API (authentication, caching, provider adapters).
3. Football provider: fixtures, standings, team form, historical results, injuries if licensed.
4. Odds provider: bookmaker and timestamp per price.
5. Prediction service: Poisson goals model as first serious baseline; later calibrated logistic/gradient-boosting model if data quality permits.
6. Evaluation: chronological backtesting, Brier score/log loss, calibration plots, ROI only after realistic bookmaker margin and closing-line assumptions.
7. Storage: match snapshots, prediction version, odds timestamp, final score, settled outcome.
8. Responsible-use controls: no guaranteed-win language, transparent model confidence, age and jurisdiction checks before any future betting-related integrations.

## Value calculation
For decimal odds `o`, raw implied probability is `1/o`. For a market with all outcomes, normalize implied probabilities to estimate bookmaker margin. Compare the model's calibrated probability with the market-implied probability. Do not display a “value” label until live odds are timestamped and the model has been validated.

## Next milestones
- Choose a data provider and review API coverage/licensing/pricing.
- Build backend proxy so provider secrets are not in the APK.
- Replace demo fixtures with real scheduled matches.
- Add odds snapshots and prediction history.
- Backtest and calibrate before presenting confidence as meaningful.
- Add tests and release signing configuration.
