# GoalTips Android

Starter project for a Portuguese football predictions app.

## Stack
- Kotlin
- Jetpack Compose + Material 3
- MVVM-friendly structure
- Demo fixtures and a transparent baseline prediction engine
- Ready for a real football data provider to be connected later

## Important
The included fixtures and odds are **illustrative demo data**, not live data or betting advice.
The baseline model is a demonstration, not a validated forecasting system.
No betting actions or payments are implemented.

## Open in Android Studio
1. Install Android Studio (current stable version).
2. Open this folder as a project.
3. Let Gradle sync.
4. Run on an Android emulator or connected Android device.

To produce an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Data-provider integration
Implement `FootballDataSource` in `data/FootballDataSource.kt` using a provider with suitable coverage, licensing and API terms. Keep API keys on a backend rather than embedding secret keys in the APK.

## Build an APK without installing Android Studio locally
This repository includes a GitHub Actions workflow. After uploading the project to a GitHub repository:
1. Open the repository's **Actions** tab.
2. Select **Build GoalTips APK**.
3. Press **Run workflow** (or push to `main`).
4. When the run finishes, open the run's **Artifacts** section and download `GoalTips-debug-apk`.
5. Extract the ZIP artifact to obtain `app-debug.apk`.

This creates a debug APK for testing. It is not a signed release APK for Play Store distribution.
