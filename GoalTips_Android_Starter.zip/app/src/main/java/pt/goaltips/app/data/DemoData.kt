package pt.goaltips.app.data

import pt.goaltips.app.domain.FootballMatch

/**
 * All teams, kickoff times, form and odds below are illustrative placeholders.
 * They are not today's fixtures, live odds or real forecasts.
 */
object DemoData {
    val matches = listOf(
        FootballMatch("demo1", "Liga Portugal", "Portugal", "20:15", "Clube da Casa", "Clube Visitante",
            listOf(3,3,1,3,1), listOf(1,0,3,1,0), 1.8, 0.9, 1.1, 1.4, "1.85 / 3.40 / 4.20"),
        FootballMatch("demo2", "Premier League", "Inglaterra", "17:30", "Northbridge FC", "Kingsport United",
            listOf(3,1,3,0,3), listOf(3,3,1,3,1), 1.7, 1.2, 1.6, 1.1, "2.60 / 3.20 / 2.55"),
        FootballMatch("demo3", "La Liga", "Espanha", "19:00", "Costa Azul CF", "Real del Valle",
            listOf(1,3,3,1,0), listOf(0,1,3,1,3), 1.5, 1.0, 1.2, 1.3, "2.05 / 3.10 / 3.75"),
        FootballMatch("demo4", "Serie A", "Itália", "20:45", "AC Borgo", "Sportiva Marina",
            listOf(3,3,1,3,3), listOf(0,1,0,3,1), 2.0, 0.8, 0.9, 1.5, "1.70 / 3.60 / 5.10")
    )
}
