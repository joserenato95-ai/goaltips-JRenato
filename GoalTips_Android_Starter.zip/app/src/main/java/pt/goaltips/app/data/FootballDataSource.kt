package pt.goaltips.app.data

import pt.goaltips.app.domain.FootballMatch

/**
 * Implement this interface with a licensed football API.
 * Keep provider credentials on a backend, never hard-code secret API keys in the APK.
 */
interface FootballDataSource {
    suspend fun getMatches(dateIso: String, competitionIds: List<String> = emptyList()): List<FootballMatch>
    suspend fun getMatchHistory(teamId: String, limit: Int = 10): List<FootballMatch>
}
