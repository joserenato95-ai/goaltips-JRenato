package pt.goaltips.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pt.goaltips.app.data.DemoData
import pt.goaltips.app.domain.PredictionEngine
import pt.goaltips.app.domain.FootballMatch

private val Night = Color(0xFF0C1210)
private val Panel = Color(0xFF17211D)
private val Green = Color(0xFF64E39A)
private val Muted = Color(0xFF9BAAA2)
private val White = Color(0xFFF3F7F4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoalTipsApp() }
    }
}

@Composable
private fun GoalTipsApp() {
    var selectedTab by remember { mutableStateOf("Hoje") }
    var selectedLeague by remember { mutableStateOf("Todas") }
    val matches = remember { DemoData.matches.map { it.copy(prediction = PredictionEngine.predict(it)) } }
    val leagues = listOf("Todas", "Portugal", "Inglaterra", "Espanha", "Itália")

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green,
            background = Night,
            surface = Panel,
            onBackground = White,
            onSurface = White
        )
    ) {
        Scaffold(
            containerColor = Night,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = White) {
                    listOf("Hoje", "Ligas", "Histórico").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = {
                                Text(when(tab) { "Hoje" -> "⚽"; "Ligas" -> "▦"; else -> "◷" }, fontSize = 18.sp)
                            },
                            label = { Text(tab) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Green,
                                selectedTextColor = Green,
                                indicatorColor = Color(0xFF263B30),
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 22.dp, bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column {
                            Text("GOAL", color = White, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                            Text("TIPS  /  ANÁLISE DE FUTEBOL", color = Green, fontSize = 10.sp, letterSpacing = 1.5.sp)
                        }
                        Surface(color = Color(0xFF20372B), shape = RoundedCornerShape(50)) {
                            Text("● DEMO", color = Green, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
                        }
                    }
                }
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(18.dp)
                    ) {
                        Text("CENTRAL DE PROGNÓSTICOS", color = Muted, fontSize = 11.sp, letterSpacing = 1.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            when(selectedTab) {
                                "Hoje" -> "Encontra valor.\nDecide com dados."
                                "Ligas" -> "Futebol sem fronteiras."
                                else -> "Aprende com o histórico."
                            },
                            color = White, fontSize = 25.sp, lineHeight = 30.sp, fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(10.dp))
                        Text("Probabilidades estimadas, forma recente e comparação com odds.", color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        leagues.forEach { league ->
                            FilterChip(
                                selected = selectedLeague == league,
                                onClick = { selectedLeague = league },
                                label = { Text(league) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF254332),
                                    selectedLabelColor = Green,
                                    labelColor = Muted
                                )
                            )
                        }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(if (selectedTab == "Histórico") "FORMA DE DEMONSTRAÇÃO" else "JOGOS EM DESTAQUE", color = White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("${matches.count { selectedLeague == "Todas" || it.leagueCountry == selectedLeague }} jogos", color = Muted, fontSize = 12.sp)
                    }
                }
                val visible = matches.filter { selectedLeague == "Todas" || it.leagueCountry == selectedLeague }
                items(visible) { match -> MatchCard(match) }
                item {
                    Text(
                        "⚠ Dados fictícios para demonstração. As probabilidades não garantem resultados nem lucro. Confirma sempre os dados reais.",
                        color = Muted, fontSize = 11.sp, lineHeight = 16.sp,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MatchCard(match: FootballMatch) {
    val prediction = match.prediction
    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("${match.league} · ${match.kickoff}", color = Muted, fontSize = 11.sp)
            Surface(color = Color(0xFF24352B), shape = RoundedCornerShape(6.dp)) {
                Text("ANÁLISE", color = Green, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp))
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
                Text(match.home, color = White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("Casa", color = Muted, fontSize = 11.sp)
            }
            Text("VS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp))
            Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                Text(match.away, color = White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("Visitante", color = Muted, fontSize = 11.sp)
            }
        }
        HorizontalDivider(color = Color(0xFF2B3932))
        Text("PROBABILIDADES ESTIMADAS", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            ProbabilityPill("1", prediction.homeWin, Modifier.weight(1f))
            ProbabilityPill("X", prediction.draw, Modifier.weight(1f))
            ProbabilityPill("2", prediction.awayWin, Modifier.weight(1f))
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("Mercado sugerido", color = Muted, fontSize = 11.sp)
                Text(prediction.market, color = Green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Confiança do modelo", color = Muted, fontSize = 10.sp)
                Text("${prediction.confidence}%", color = White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text("Odds demonstrativas: ${match.demoOdds}", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun ProbabilityPill(label: String, probability: Int, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.background(Color(0xFF223129), RoundedCornerShape(10.dp)).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(3.dp))
        Text("$probability%", color = Green, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}
