package pt.goaltips.app.domain

import kotlin.math.roundToInt

/**
 * Educational baseline only. This is NOT a trained or validated betting model.
 * Replace with a calibrated model trained on historical, time-stamped match data.
 */
object PredictionEngine {
    fun predict(match: FootballMatch): MatchPrediction {
        val homeFormScore = formScore(match.homeForm)
        val awayFormScore = formScore(match.awayForm)
        val homeAttack = (match.homeGoalsForAvg + match.awayGoalsAgainstAvg) / 2.0
        val awayAttack = (match.awayGoalsForAvg + match.homeGoalsAgainstAvg) / 2.0

        val homeRaw = (1.0 + homeFormScore * 0.14 + (homeAttack - awayAttack) * 0.10).coerceAtLeast(0.2)
        val awayRaw = (1.0 + awayFormScore * 0.14 + (awayAttack - homeAttack) * 0.10).coerceAtLeast(0.2)
        val drawRaw = (0.78 + (2.8 - homeAttack - awayAttack).coerceAtLeast(0.0) * 0.12).coerceAtLeast(0.25)
        val total = homeRaw + awayRaw + drawRaw
        val home = (homeRaw / total * 100).roundToInt().coerceIn(5, 85)
        val draw = (drawRaw / total * 100).roundToInt().coerceIn(5, 60)
        val away = (100 - home - draw).coerceAtLeast(5)
        val normalizedHome = (home * 100.0 / (home + draw + away)).roundToInt()
        val normalizedDraw = (draw * 100.0 / (home + draw + away)).roundToInt()
        val normalizedAway = 100 - normalizedHome - normalizedDraw

        val market = when {
            normalizedHome >= 48 -> "Vitória da casa (1)"
            normalizedAway >= 42 -> "Vitória visitante (2)"
            else -> "Dupla possibilidade (1X)"
        }
        val confidence = maxOf(normalizedHome, normalizedDraw, normalizedAway).coerceIn(25, 70)
        return MatchPrediction(normalizedHome, normalizedDraw, normalizedAway, market, confidence)
    }

    private fun formScore(form: List<Int>): Double {
        if (form.isEmpty()) return 0.0
        // 3 = win, 1 = draw, 0 = loss
        return form.takeLast(5).average() / 3.0
    }
}
