package pt.goaltips.app.domain

data class FootballMatch(
    val id: String,
    val league: String,
    val leagueCountry: String,
    val kickoff: String,
    val home: String,
    val away: String,
    val homeForm: List<Int>,
    val awayForm: List<Int>,
    val homeGoalsForAvg: Double,
    val homeGoalsAgainstAvg: Double,
    val awayGoalsForAvg: Double,
    val awayGoalsAgainstAvg: Double,
    val demoOdds: String,
    val prediction: MatchPrediction? = null
)

data class MatchPrediction(
    val homeWin: Int,
    val draw: Int,
    val awayWin: Int,
    val market: String,
    val confidence: Int
)
